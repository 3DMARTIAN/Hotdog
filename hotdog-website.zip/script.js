function showMessage() {
  alert("Thanks for ordering a delicious hot dog! 🌭");
}
